#!/bin/bash
TOP=/opt/ovis
export LD_LIBRARY_PATH=$TOP/lib/:$LD_LIBRARY_PATH
export LDMSD_PLUGIN_LIBPATH=$TOP/lib/ovis-ldms
export ZAP_LIBPATH=$TOP/lib/ovis-ldms
export PYTHONPATH=$TOP/lib/python3.10/site-packages/:$PYTHONPATH
export PATH=$TOP/sbin:$TOP/bin:$PATH

# set variables for LDMS samplers
export COMP_ID_1=1
export COMP_ID_2=2
