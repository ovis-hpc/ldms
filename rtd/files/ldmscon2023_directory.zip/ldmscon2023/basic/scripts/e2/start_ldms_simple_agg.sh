#!/bin/bash

TOP=/opt/ovis
export LD_LIBRARY_PATH=$TOP/lib64/:$LD_LIBRARY_PATH
export LDMSD_PLUGIN_LIBPATH=$TOP/lib/ovis-ldms
export PATH=$TOP/sbin:$TOP/bin:$PATH
export ZAP_LIBPATH=$TOP/lib/ovis-ldms
export PYTHONPATH=$TOP/lib/python3.10/site-packages/:$PYTHONPATH

# set variables for LDMS samplers
export COMP_ID_1=1
export COMP_ID_2=2
export HOSTNAME=${HOSTNAME}

ldmsd -x sock:20001 -l
/root/ldmscon2023/basic/logs/simple_aggd.log -c /root/ldmscon2023/basic/conf/e2/simple_agg.conf
